# 07-extended-resources

Purpose, source-of-truth files, generated files, contribution rules, and related survey sections are documented here.
