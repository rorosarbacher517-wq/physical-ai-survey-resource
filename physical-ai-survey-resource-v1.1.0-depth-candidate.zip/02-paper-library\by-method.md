# Papers by method

Generated from canonical metadata. Do not edit manually.


## hybrid-numerical-machine-learning

- [paper-10-5194-egusphere-egu23-16443](cards/paper-10-5194-egusphere-egu23-16443.md): Hybrid machine learning model of coupled carbon and water cycles (2023)
- [paper-10-22541-essoar-172526720-02219772-v1](cards/paper-10-22541-essoar-172526720-02219772-v1.md): Exploring Optimal Complexity for Water Stress Representation in Terrestrial Carbon Models: A Hybrid-Machine Learning Model Approach (2024)
- [paper-10-2139-ssrn-5352244](cards/paper-10-2139-ssrn-5352244.md): Towards Consistent Carbon Monitoring: The Role of Satellite Resolution and Process-Informed Machine Learning in Terrestrial Carbon Cycle Modelling (2025)
- [paper-10-1109-lgrs-2025-3541893-mm1](cards/paper-10-1109-lgrs-2025-3541893-mm1.md): UFLUX v2.0: A Process-Informed Machine Learning Framework for Efficient and Explainable Modelling of Terrestrial Carbon Uptake_supp1-3541893.pdf (2025)

## machine-learning-upscaling

- [paper-10-1034-j-1600-0889-47-issue1-15-x](cards/paper-10-1034-j-1600-0889-47-issue1-15-x.md): Monitoring seasonal and interannual variations of gross primary productivity, net primary productivity and net ecosystem productivity using a diagnostic model and remotely-sensed data (1995)
- [paper-10-1016-0034-42579500258-8](cards/paper-10-1016-0034-42579500258-8.md): Estimating net ecosystem exchange of carbon using the normalized difference vegetation index and an ecosystem model (1996)
- [paper-10-1016-j-rse-2005-10-009](cards/paper-10-1016-j-rse-2005-10-009.md): Evaluation of MODIS Gross Primary Productivity (GPP) in tropical monsoon regions (2006)
- [paper-10-1111-j-1600-0889-2007-00274-x](cards/paper-10-1111-j-1600-0889-2007-00274-x.md): The surface energy, water, carbon flux and their intercorrelated seasonality in a global climate-vegetation coupled model (2007)
- [paper-10-1109-icmlc-2008-4620630](cards/paper-10-1109-icmlc-2008-4620630.md): Spatialization of station measured net ecosystem exchange using artificial neural network (2008)
- [paper-10-1029-2010gb003900](cards/paper-10-1029-2010gb003900.md): Atmospheric constraints on gross primary productivity and net ecosystem productivity: Results from a carbon‐cycle data assimilation system (2012)
- [paper-10-1007-978-1-62703-688-7-21](cards/paper-10-1007-978-1-62703-688-7-21.md): Ecophysiological Process-Based Model to Simulate Carbon Fluxes in Plants (2014)
- [paper-10-4135-9781446247501-n1783](cards/paper-10-4135-9781446247501-n1783.md): GROSS PRIMARY PRODUCTIVITY (GPP) (2014)
- [paper-10-1016-j-agrformet-2014-04-011](cards/paper-10-1016-j-agrformet-2014-04-011.md): Joint data assimilation of satellite reflectance and net ecosystem exchange data constrains ecosystem carbon fluxes at a high-elevation subalpine forest (2014)
- [paper-10-3334-ornldaac-1315](cards/paper-10-3334-ornldaac-1315.md): CMS: Modeled Net Ecosystem Exchange at 3-hourly Time Steps, 2004-2010 (2016)
- [paper-10-15486-ngt-1279968](cards/paper-10-15486-ngt-1279968.md): Global 4 km resolution monthly gridded Gross Primary Productivity (GPP) data set derived from FLUXNET2015 (2016)
- [paper-10-5194-bg-2018-270-rc1](cards/paper-10-5194-bg-2018-270-rc1.md): Norton et al. “Estimating global gross primary productivity using chlorophyll fluorescence and a data assimilation system with the BETHY-SCOPE model”. (2018)
- [paper-10-33915-etd-7022](cards/paper-10-33915-etd-7022.md): Climatic and Ecohydrologic Linkages of Net Ecosystem Exchanges (NEE) across Diverse Ecosystems (2019)
- [paper-10-1016-j-ifacsc-2019-100036](cards/paper-10-1016-j-ifacsc-2019-100036.md): Net Ecosystem Exchange (NEE) simulation in maize using artificial neural networks (2019)
- [paper-10-1109-igarss-2019-8900191](cards/paper-10-1109-igarss-2019-8900191.md): Updated Data-Driven GPP and NEE Estimation with Remote Sensing and Machine Learning Across Asia (2019)
- [paper-10-5194-bg-2020-50-rc1](cards/paper-10-5194-bg-2020-50-rc1.md): A new study on interannual relationships between vegetation LAI and water/energy/carbon fluxes across global ecosystems using flux measurements (2020)
- [paper-10-35370-bjost-2020-2-2-06](cards/paper-10-35370-bjost-2020-2-2-06.md): Estimation of Gross Primary Productivity (GPP) using Moderate Resolution Imaging Spectroradiometer (MODIS) (2020)
- [paper-10-5194-egusphere-egu2020-2135](cards/paper-10-5194-egusphere-egu2020-2135.md): GPP and NEE estimation for global forests based on a deep convolutional neural network (2020)
- [paper-10-3390-rs13132448](cards/paper-10-3390-rs13132448.md): Comparison of Machine Learning Methods to Up-Scale Gross Primary Production (2021)
- [paper-10-1029-2021ms002802](cards/paper-10-1029-2021ms002802.md): Machine Learning‐Based Modeling of Vegetation Leaf Area Index and Gross Primary Productivity Across North America and Comparison With a Process‐Based Model (2021)
- [paper-10-5194-esd-2021-38](cards/paper-10-5194-esd-2021-38.md): Process-based analysis of terrestrial carbon flux predictability (2021)
- [paper-10-1002-9781119793403-ch17](cards/paper-10-1002-9781119793403-ch17.md): Process‐Based Carbon Sequestration Study with Reference to the Energy‐Water‐Carbon Flux in a Forest Ecosystem (2021)
- [paper-10-1016-j-ecoinf-2022-101697](cards/paper-10-1016-j-ecoinf-2022-101697.md): Machine learning approach to predict terrestrial gross primary productivity using topographical and remote sensing data (2022)
- [paper-10-5194-egusphere-egu22-11111](cards/paper-10-5194-egusphere-egu22-11111.md): Machine learning based estimation of regional Net Ecosystem Exchange (NEE) constrained by atmospheric inversions and ecosystem observations (2022)
- [paper-10-5194-egusphere-2022-640-supplement](cards/paper-10-5194-egusphere-2022-640-supplement.md): Supplementary material to "Synergy between TROPOMI sun-induced chlorophyll fluorescence and MODIS spectral reflectance for understanding the dynamics of gross primary productivity at integrated carbon observatory system (ICOS) ecosystem flux sites" (2022)
- [paper-10-31223-x5r957](cards/paper-10-31223-x5r957.md): CEDAR-GPP: spatiotemporally upscaled estimates of gross primary productivity incorporating CO2 fertilization (2023)
- [paper-10-1016-j-agwat-2024-108706](cards/paper-10-1016-j-agwat-2024-108706.md): A coupled hourly water-carbon flux model at plot and field scales for water-saving irrigated rice paddy (2024)
- [paper-10-5194-egusphere-egu24-13899](cards/paper-10-5194-egusphere-egu24-13899.md): Estimating CO2 Flux at 30 Meter Resolution Using Machine Learning (2024)
- [paper-10-1201-9781032711126-34](cards/paper-10-1201-9781032711126-34.md): Global Carbon Cycle Data Assimilation Using Earth Observation (2024)
- [paper-10-2139-ssrn-4801189](cards/paper-10-2139-ssrn-4801189.md): How Real is the Correlation between Gross Primary Productivity and Ecosystem Respiration? (2024)
- [paper-10-23967-isc-2024-304](cards/paper-10-23967-isc-2024-304.md): Machine Learning-Based Modeling of Net Ecosystem Exchange Using Numerical Weather Data and Satellite Images (2024)
- [paper-10-3390-rs17213615](cards/paper-10-3390-rs17213615.md): Digital Twin-Ready Earth Observation: Operationalizing GeoML for Agricultural CO2 Flux Monitoring at Field Scale (2025)
- [paper-10-5194-egusphere-2025-2517](cards/paper-10-5194-egusphere-2025-2517.md): Improving Terrestrial Carbon Flux Simulations With Machine Learning and Global Earth Observations (2025)
- [paper-10-4018-979-8-3373-2091-5-ch014](cards/paper-10-4018-979-8-3373-2091-5-ch014.md): Machine Learning Algorithms for Modeling Carbon Flux in Ecosystems (2025)
- [paper-10-1016-j-rsase-2025-101728](cards/paper-10-1016-j-rsase-2025-101728.md): Upscaling CO2 fluxes from agricultural drained lowland peatlands in England using remote sensing and machine learning (2025)
- [paper-10-3390-rs17030426](cards/paper-10-3390-rs17030426.md): Upscaling Tower-Based Net Ecosystem Productivity to 250 m Resolution with Flux Site Distribution Considerations (2025)
- [paper-10-3390-su18041944](cards/paper-10-3390-su18041944.md): Assessing Proxy-Based Grassland Gross Primary Productivity Using Machine Learning Approaches and Multi-Source Remote Sensing (2026)
- [paper-10-2139-ssrn-6298873](cards/paper-10-2139-ssrn-6298873.md): High-Resolution Daily Net Ecosystem Exchange (NEE) Estimation over Rice Paddies Using Machine Learning and Multi-Source Satellite and Meteorological Data (2026)
- [paper-10-3390-rs18122016](cards/paper-10-3390-rs18122016.md): MODIS-Based Estimation of Grassland Gross Primary Productivity in Inner Mongolia Using a ConvTransformer Deep Learning Model (2026)
- [paper-10-5194-egusphere-2026-3281](cards/paper-10-5194-egusphere-2026-3281.md): Machine-learning projections of boreal forest gross primary productivity under future climate change (2026)
- [paper-10-5194-egusphere-egu26-10329](cards/paper-10-5194-egusphere-egu26-10329.md): VODCA2GPP: High Resolution GPP Estimation in the Mediterranean basin from Vegetation Optical Depth Using Machine Learning (2026)

## neural-operators

- [paper-10-2139-ssrn-4527164](cards/paper-10-2139-ssrn-4527164.md): Physics-Informed Invertible Neural Network for the Koopman Operator Learning (2023)
- [paper-10-1016-j-applthermaleng-2026-130757](cards/paper-10-1016-j-applthermaleng-2026-130757.md): Physics-informed Fourier neural operator for surrogate prediction of tunnel fire temperature field (2026)

## observation-operator-methods

- [paper-10-1175-jhm467-1](cards/paper-10-1175-jhm467-1.md): Comparing Aircraft-Based Remotely Sensed Energy Balance Fluxes with Eddy Covariance Tower Data Using Heat Flux Source Area Functions (2005)
- [paper-10-3410-f-1028523-341152](cards/paper-10-3410-f-1028523-341152.md): Faculty Opinions recommendation of Estimating diurnal to annual ecosystem parameters by synthesis of a carbon flux model with eddy covariance net ecosystem exchange observations. (2005)
- [paper-10-5194-essd-2016-36-rc2](cards/paper-10-5194-essd-2016-36-rc2.md): Review on 'Understanding the representativeness of FLUXNET for upscaling carbon flux from eddy covariance measurements' (2016)
- [paper-10-5194-essd-2016-36](cards/paper-10-5194-essd-2016-36.md): Understanding the representativeness of FLUXNET for upscaling carbon flux from eddy covariance measurements (2016)
- [paper-10-1109-igarss-2017-8128126](cards/paper-10-1109-igarss-2017-8128126.md): Remote estimation of maize carbon sequestration capacity based on eddy covariance flux measurements (2017)
- [paper-10-5194-egusphere-egu2020-19498](cards/paper-10-5194-egusphere-egu2020-19498.md): Urban carbon dioxide flux monitoring using Eddy Covariance and Earth Observation: An introduction to diFUME project (2020)
- [paper-10-3390-atmos12020281](cards/paper-10-3390-atmos12020281.md): Correction of Eddy Covariance Based Crop ET Considering the Heat Flux Source Area (2021)
- [paper-10-3390-rs13214229](cards/paper-10-3390-rs13214229.md): Estimating Gross Primary Productivity (GPP) over Rice–Wheat-Rotation Croplands by Using the Random Forest Model and Eddy Covariance Measurements: Upscaling and Comparison with the MODIS Product (2021)
- [paper-10-3390-rs13244976](cards/paper-10-3390-rs13244976.md): Gap-Filling Eddy Covariance Latent Heat Flux: Inter-Comparison of Four Machine Learning Model Predictions and Uncertainties in Forest Ecosystem (2021)
- [paper-10-1016-j-agrformet-2022-108980](cards/paper-10-1016-j-agrformet-2022-108980.md): Two for one: Partitioning CO2 fluxes and understanding the relationship between solar-induced chlorophyll fluorescence and gross primary productivity using machine learning (2022)
- [paper-10-53846-goediss-9953](cards/paper-10-53846-goediss-9953.md): Flux measurements at the land-atmosphere interface: Extending the theory and implementation of the true eddy accumulation and eddy covariance measurement techniques (2023)
- [paper-10-1007-s10668-022-02276-9](cards/paper-10-1007-s10668-022-02276-9.md): Prediction of the CO2 emission across grassland and cropland using tower-based eddy covariance flux measurements: a machine learning approach (2023)
- [paper-10-5194-egusphere-egu23-15533](cards/paper-10-5194-egusphere-egu23-15533.md): Reducing the effects of weather on the sampling bias in tall tower eddy covariance flux measurements (2023)
- [paper-10-5194-ems2023-530](cards/paper-10-5194-ems2023-530.md): Temporal relationship of solar-Induced chlorophyll fluorescence (SIF) and gross primary productivity (GPP) measured at ground to satellite scale over different ecosystems (2023)
- [paper-10-5194-egusphere-egu24-7413](cards/paper-10-5194-egusphere-egu24-7413.md): Addressing forest canopy decoupling in eddy covariance flux measurement networks (2024)
- [paper-10-5194-egusphere-egu24-9398](cards/paper-10-5194-egusphere-egu24-9398.md): Integrating UAS-based lidar data in eddy covariance flux footprint modelling (2024)
- [paper-10-5194-egusphere-egu24-22211](cards/paper-10-5194-egusphere-egu24-22211.md): Optimising the sampling strategy in tall tower eddy covariance flux measurements (2024)
- [paper-10-1080-01431161-2024-2312266](cards/paper-10-1080-01431161-2024-2312266.md): Uniform upscaling techniques for eddy covariance FLUXes (UFLUX) (2024)
- [paper-10-5194-egusphere-egu25-4594](cards/paper-10-5194-egusphere-egu25-4594.md): Addressing a sensible heat bias in open-path eddy covariance carbon dioxide flux measurements (2025)
- [paper-10-2139-ssrn-5252965](cards/paper-10-2139-ssrn-5252965.md): Can Matching High Spatial Resolution Landsat Data with Eddy-Covariance Flux Footprints Improve the Correlation between Nirv and Gpp? (2025)
- [paper-10-5194-egusphere-egu25-17514](cards/paper-10-5194-egusphere-egu25-17514.md): Enhancing quantification of local carbon sinks through Eddy Covariance CO2 Flux and Machine Learning (2025)
- [paper-10-5194-egusphere-egu25-11746](cards/paper-10-5194-egusphere-egu25-11746.md): Evaluating a Flux Footprint Model Using Tracer Release Experiments and Tall Tower Eddy Covariance Measurements (2025)
- [paper-10-5194-egusphere-egu25-14709](cards/paper-10-5194-egusphere-egu25-14709.md): Investigation of eco-hydrogical processes influencing Himalayan Chir-Pine net ecosystem exchange using machine learning classifiers (2025)
- [paper-10-5194-egusphere-egu25-14398](cards/paper-10-5194-egusphere-egu25-14398.md): Modelling solar-induced chlorophyll fluorescence (SIF) with terrestrial biosphere model QUINCY (2025)
- [paper-10-1016-j-fecs-2025-100368](cards/paper-10-1016-j-fecs-2025-100368.md): Predicting gross primary productivity of poplar plantations based on solar-induced chlorophyll fluorescence using an improved machine learning model (2025)
- [paper-10-5194-icuc12-821](cards/paper-10-5194-icuc12-821.md): Spatial and temporal variations of carbon dioxide flux to the atmosphere in Krakow, Poland: four years of eddy covariance measurements (2025)
- [paper-10-1109-jstars-2026-3706054](cards/paper-10-1109-jstars-2026-3706054.md): Improving High-Resolution GPP Estimation by Incorporating Flux Footprint Weighting with Mechanistic Canopy Partitioning (2026)
- [paper-10-1109-jstars-2026-3706054-mm1](cards/paper-10-1109-jstars-2026-3706054-mm1.md): Improving High-Resolution GPP Estimation by Incorporating Flux Footprint Weighting with Mechanistic Canopy Partitioning_supp1-3706054.docx (2026)
- [paper-10-5194-egusphere-egu26-9141](cards/paper-10-5194-egusphere-egu26-9141.md): “Take one, get two!” - Spatial flux decomposition for eddy covariance towers (2026)

## physics-constrained-objectives

- [paper-10-1021-acs-jpca-1c05102-s001](cards/paper-10-1021-acs-jpca-1c05102-s001.md): Stiff-PINN: Physics-Informed Neural Network for Stiff Chemical Kinetics (2021)
- [paper-10-53962-yg21-zyxf](cards/paper-10-53962-yg21-zyxf.md): Physics-informed Machine Learning: The Next Evolution in Neural Network Development (2023)
- [paper-10-2139-ssrn-4601468](cards/paper-10-2139-ssrn-4601468.md): Uncertainty Quantification Study of the Physics-Informed Machine Learning Models for Critical Heat Flux Prediction (2023)
- [paper-10-5194-egusphere-egu24-5488](cards/paper-10-5194-egusphere-egu24-5488.md): Global long-term hourly 9 km terrestrial water-energy-carbon fluxes with physics-informed machine learning (2024)
- [paper-10-1016-j-jcp-2023-112603](cards/paper-10-1016-j-jcp-2023-112603.md): NAS-PINN: Neural architecture search-guided physics-informed neural network for solving PDEs (2024)
- [paper-10-21203-rs-3-rs-6880919-v1](cards/paper-10-21203-rs-3-rs-6880919-v1.md): HOMO-PINN: Hyperparameter Optimization of a Multi-Output Physics-Informed Neural Network (2025)
- [paper-10-1021-acs-jctc-5c00090-s001](cards/paper-10-1021-acs-jctc-5c00090-s001.md): Learning Pairwise Interaction for Extrapolative and Interpretable Machine Learning Interatomic Potentials with Physics-Informed Neural Network (2025)
- [paper-10-36227-techrxiv-175760430-01088421-v1](cards/paper-10-36227-techrxiv-175760430-01088421-v1.md): Learning to PINN Down PDEs: Lessons from Developing a Physics-Informed Neural Network Framework (2025)
- [paper-10-3390-rs17233805](cards/paper-10-3390-rs17233805.md): Physics-Informed Transformer Networks for Interpretable GNSS-R Wind Speed Retrieval (2025)
- [paper-10-2139-ssrn-5207041](cards/paper-10-2139-ssrn-5207041.md): Pinn-Phase: A Physics-Informed Neural Network Hybrid Framework for Energy-Based Transfer Learning in Diffuse Interface Problems (2025)
- [paper-10-2139-ssrn-5749490](cards/paper-10-2139-ssrn-5749490.md): SDD-PINN: Physics-informed neural network for single droplet drying (2025)
- [paper-10-2139-ssrn-7003298](cards/paper-10-2139-ssrn-7003298.md): Bridging from Canopy to Ecosystem: Physics-Informed Machine Learning Partitions Carbon–Water Fluxes to Reveal Divergent Water Use Strategies (2026)

## scientific-foundation-models

- [paper-10-5194-egusphere-egu23-3276](cards/paper-10-5194-egusphere-egu23-3276.md): A large-scale flood modeling using geometry-adaptive physics-informed neural solver and Earth observation data (2023)
- [paper-10-5194-egusphere-egu24-1760](cards/paper-10-5194-egusphere-egu24-1760.md): EarthPT: a foundation model for Earth Observation (2024)
- [paper-10-1038-s44287-025-00208-z](cards/paper-10-1038-s44287-025-00208-z.md): Advancing Earth observation with a multi-modal remote sensing foundation model (2025)

## theory-optimization-generalization

- [paper-10-31219-osf-io-p95zn](cards/paper-10-31219-osf-io-p95zn.md): Scientific Machine Learning (SciML) Surrogates for Industry, Part 1: The Guiding Questions (2024)
- [paper-10-3390-rs18101529](cards/paper-10-3390-rs18101529.md): Geographic Bias Analysis and Cross-Domain Generalization in Deep Learning-Based Building Damage Assessment (2026)

## uncertainty-quantification

- [paper-10-31223-x5xw61](cards/paper-10-31223-x5xw61.md): Can machine learning improve carbon storage? Synergies of deep learning, uncertainty quantification and intelligent process control (2021)
- [paper-10-1049-sbew552e-ch7](cards/paper-10-1049-sbew552e-ch7.md): Machine learning approaches towards uncertainty quantification (2021)
- [paper-10-5194-egusphere-egu21-9254](cards/paper-10-5194-egusphere-egu21-9254.md): Machine learning-based uncertainty quantification for data assimilation: a simple model experiment (2021)
- [paper-10-21203-rs-3-rs-640751-v1](cards/paper-10-21203-rs-3-rs-640751-v1.md): Time-Series Uncertainty Quantification of Foundation Settlement with Kernel Based Extreme Learning Machine (2021)
- [paper-10-1007-978-3-030-95231-0-6](cards/paper-10-1007-978-3-030-95231-0-6.md): Uncertainty Quantification with Extreme Learning Machine (2022)
- [paper-10-1615-jmachlearnmodelcomput-2024055786](cards/paper-10-1615-jmachlearnmodelcomput-2024055786.md): MULTI-FIDELITY MACHINE LEARNING FOR UNCERTAINTY QUANTIFICATION AND OPTIMIZATION (2024)
- [paper-10-17760-d20659778](cards/paper-10-17760-d20659778.md): Uncertainty quantification in pain assessment through machine learning (2024)
